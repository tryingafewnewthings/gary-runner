# GARY EATS! | Bridge Transition | CANDIDATE 01

Nine **separate transparent PNG** candidates: A, B, C, D, E, F, G, H1, H2. Generated from one original image-model atlas and cropped to remove ALL labels. No water is baked into masonry or deck sprites.

## Current state
- **ART UNVERIFIED:** style match, height profile and perspective require human/game-engine approval; no native gameplay engine capture executed.
- **TRUE ALPHA:** source PNGs have substantial transparency; individually cropped from a genuine RGBA atlas.
- **GEOMETRY:** registration JSON holds 360×640 world units and exact target rectangles; pixel dimensions are independent.
- **VISUALS:** `reviews/*mockup*` images are explanatory composites, NOT real game screenshots. `reference-negative-existing-gameplay.png` is user-supplied real gameplay.
- **INTEGRATION:** the patch removes the original 150-unit stretched-cobble wedge and uses a 28-unit threshold at each end. The nine PNGs are NOT installed into public normal Play until gameplay QA and art sign-off.

## Integration plan
1. Apply or review `gary-bridge-user.js` patch on a branch.
2. Keep bridges and river/wilderness independent and register PNGs only after native day/night/rain in-engine evidence.
3. Load assets into lower masonry / terrain / shadow / deck layers with per-sprite world screen Y = bridgeNear - 800 + rect.y. Keep actors between deck and foreground parapet.
4. Check continuity through entry, crossing, exit, collision and heavy rain. No physical Safari test has occurred.
