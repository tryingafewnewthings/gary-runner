Gary Eats! approved bridge riverbanks — source extracted PNGs.

The GitHub branch feature/approved-bridge-bank-sprites-20261025 adds a drawBanks render pass. Upload these two PNGs under art/bridge/approved-shore/ to activate it. DO NOT merge without binary files and native engine visual QA.
